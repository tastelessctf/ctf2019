#!/bin/sh

# ATTENTION: The terminal inside this qemu runs in non-canonical mode.
# We recommend to run the challenge in socat:
# socat tcp-l:30301,fork,reuseaddr exec:"./run.sh"

qemu-system-aarch64 \
    -nographic \
    -smp 3 \
    -machine virt,secure=on -cpu cortex-a57 \
    -d unimp -semihosting-config enable,target=native \
    -m 1057 \
    -bios bl1.bin \
    -initrd rootfs.cpio.gz \
    -kernel Image -no-acpi \
    -monitor null -serial stdio
